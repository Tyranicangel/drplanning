module.exports={
	'secret':'tyranicangel',
	'database':'mongodb://localhost/drplanning',
	'environment':'development',
}